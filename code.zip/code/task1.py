import cv2
import numpy as np
import matplotlib.pyplot as plt
import time

def otsu_thresholding(image):
    # 使用大津法进行阈值分割
    t, thresholded_image = cv2.threshold(image, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    print("opencv自带大津法最佳阈值为：", t)
    return thresholded_image

def otsu_hand_thresholding(image):
    # 计算直方图
    hist, _ = np.histogram(image.flatten(), bins=256, range=[0, 256])
    total_pixels = image.size
    # 归一化直方图
    prob = hist / total_pixels
    # 初始化变量
    max_variance = 0
    best_threshold = 0
    # 全局平均灰度值
    total_mean = np.sum(np.arange(256) * prob)
    weight_background = 0
    mean_background = 0

    # 迭代每个可能的阈值
    for t in range(256):
        weight_background += prob[t]
        if weight_background == 0:
            continue

        weight_foreground = 1 - weight_background
        if weight_foreground == 0:
            break
        # 计算前景与后景的均值
        mean_background += t * prob[t]
        mean_foreground = (total_mean - mean_background) / weight_foreground
        # 计算前景和背景的方差
        variance_background = np.sum(((np.arange(t + 1) - mean_background) ** 2) * prob[:t + 1]) / weight_background
        variance_foreground = np.sum(((np.arange(t + 1, 256) - mean_foreground) ** 2) * prob[t + 1:]) / weight_foreground

        # 计算类间方差
        variance_between = weight_background * (mean_background - t) ** 2 + weight_foreground * (mean_foreground - t) ** 2
        # 计算类内方差
        variance_within = weight_background * variance_background * variance_background + weight_foreground * variance_foreground * variance_foreground
        # 更新最大类间方差和最佳阈值
        if variance_within != 0:
            if variance_between / variance_within > max_variance:
                max_variance = variance_between / variance_within
                best_threshold = t
    print("手动大津法最佳阈值为：", best_threshold)
    # _, thresholded_image = cv2.threshold(image, best_threshold, 255, cv2.THRESH_BINARY)
    thresholded_image = np.where(image >= best_threshold, 255, 0).astype(np.uint8)
    return thresholded_image

def iterative_bisection(image, max_iter=100, epsilon=0.01):
    # image = cv2.equalizeHist(image)
    # 迭代二分法进行阈值分割
    low, high = 0, 255
    previous_mid = -100
    for _ in range(max_iter):
        mid = (low + high) // 2
        lower_mean = image[image <= mid].mean() if np.any(image <= mid) else 0
        upper_mean = image[image > mid].mean() if np.any(image > mid) else 0

        if abs(previous_mid - mid) < epsilon:
            break
        previous_mid = mid

        low = lower_mean
        high = upper_mean

    # _, thresholded_image = cv2.threshold(image, mid, 255, cv2.THRESH_BINARY)
    thresholded_image = np.where(image >= mid, 255, 0).astype(np.uint8)
    print("手动迭代二分法最佳阈值为：", mid)
    return thresholded_image


# 读取图像并转换为灰度图
image_path = 'dataset10/5.jpg'  # 请替换为你的车牌图像路径
image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)

start_time = time.time()
# 应用opencv大津法
otsu_result1 = otsu_thresholding(image)
print('Otsu opencv Thresholding uses: ',time.time()-start_time)

start_time = time.time()
# 应用手动大津法
otsu_result2 = otsu_hand_thresholding(image)
print('Otsu hand Thresholding uses: ',time.time()-start_time)

start_time = time.time()
# 应用迭代二分法
iterative_result = iterative_bisection(image)
print('Iterative Bisection uses:',time.time()-start_time)

# 显示结果
plt.figure(figsize=(12, 6))
plt.subplot(1, 4, 1)
plt.title('Original Image')
plt.imshow(image, cmap='gray')
plt.axis('off')

plt.subplot(1, 4, 2)
plt.title('Otsu opencv Thresholding')
plt.imshow(otsu_result1, cmap='gray')
plt.axis('off')

plt.subplot(1, 4, 3)
plt.title('Otsu hand Thresholding')
plt.imshow(otsu_result2, cmap='gray')
plt.axis('off')

plt.subplot(1, 4, 4)
plt.title('Iterative Bisection')
plt.imshow(iterative_result, cmap='gray')
plt.axis('off')

plt.tight_layout()
plt.show()