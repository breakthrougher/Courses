import cv2
import numpy as np

img_path = 'dataset10/car5.bmp'

# 调整尺寸
def resize_img(img):
    height,width = img.shape[:-1]
    # 限制最大像素为400
    scale = 400/max(height, width)
    img = cv2.resize(img, None, fx=scale, fy=scale,interpolation=cv2.INTER_CUBIC)
    return img

# 灰度拉伸
def stretch(img):
    maxi = img.max()
    mini = img.min()
    for i in range(img.shape[0]):
        for j in range(img.shape[1]):
            img[i,j] = 255/(maxi-mini)*img[i,j] - (255*mini)/(maxi-mini)
    return img

# 二值化
def binarization(img):
    ret, img_binary = cv2.threshold(img, 0, 255, cv2.THRESH_BINARY+cv2.THRESH_OTSU)
    return ret, img_binary

# 边缘检测
def myCanny(img, low_threshold, high_threshold):
    img_canny = cv2.Canny(img, low_threshold, high_threshold)
    return img_canny

# 形态学处理 开闭运算
def opening_with_closing(img):
    # 进行闭运算
    kernel = np.ones((8, 20), np.uint8)  # 定义结构元素
    # kernel = np.ones((2, 10), np.uint8)  # 定义结构元素
    img_closing1 = cv2.morphologyEx(img, cv2.MORPH_CLOSE, kernel)
    cv2.imshow("Closing image1", img_closing1)
    cv2.waitKey(0)
    kernel = np.ones((4, 15), np.uint8)  # 定义结构元素
    # kernel = np.ones((2, 15), np.uint8)  # 定义结构元素
    img_closing = cv2.morphologyEx(img_closing1, cv2.MORPH_CLOSE, kernel)
    cv2.imshow("Closing image2", img_closing)
    cv2.waitKey(0)
    kernel = np.ones((4, 6), np.uint8)  # 定义结构元素
    # 进行开运算
    img_opening1 = cv2.morphologyEx(img_closing, cv2.MORPH_OPEN, kernel)
    cv2.imshow("Opening_1 image", img_opening1)
    cv2.waitKey(0)
    # 再次进行开运算
    kernel = np.ones((8, 20), np.uint8)
    img_opening2 = cv2.morphologyEx(img_opening1, cv2.MORPH_OPEN, kernel)
    cv2.imshow("Opening_2 image", img_opening2)
    cv2.waitKey(0)
    return img_opening2

# 定位矩形边界坐标[上边界, 左边界, 下边界, 右边界]
def find_rect_pos(contours):
    y, x = [], []
    for p in contours:
        y.append(p[0][0])  # 收集y坐标
        x.append(p[0][1])  # 收集x坐标
    return [min(y), min(x), max(y), max(x)]

# 车牌定位
def locate_license(origin_image, img):
    # 提取轮廓
    contours, hierarchy = cv2.findContours(img, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    # 画出轮廓
    img_copy = origin_image.copy()
    img_copy = cv2.drawContours(img_copy, contours, -1, (255, 0, 0), 5)
    cv2.imshow('All Contours',img_copy)
    cv2.waitKey(0)
    block = []
    for c in contours:
        # 找出轮廓的左上点和右下点，由此计算它的面积和长度比
        pos = find_rect_pos(c)
        # 计算轮廓面积及高宽比
        a = (pos[2] - pos[0]) * (pos[3] - pos[1])  # 面积
        s = (pos[2] - pos[0]) / (pos[3] - pos[1])  # 长度比
        block.append([pos, a, s])
    # 选出面积最大的五个区域 b[1]是对第二个元素
    block = sorted(block, key=lambda b: b[1])[-5:]

    # 根绝颜色识别找到最像车牌的区域
    maxWeight, maxIndex = 0, -1
    for i in range(len(block)):
        # 高宽比、面积进行限制
        if 2 <= block[i][2] <= 4 and 1000 <= block[i][1] <= 20000:
            b = origin_image[block[i][0][1]: block[i][0][3], block[i][0][0]: block[i][0][2]]
            # 颜色空间变换 hsv更适合颜色识别
            hsv = cv2.cvtColor(b, cv2.COLOR_BGR2HSV)
            # 使用指定的 HSV 颜色范围构建掩膜，提取符合条件的颜色部分
            lower = np.array([100, 43, 46])
            upper = np.array([124, 255, 255])
            mask = cv2.inRange(hsv, lower, upper)
            # 计算掩膜中符合颜色条件的像素点的权重
            w1 = 0
            for m in mask:
                w1 += m / 255
            # 统计所有符合条件的像素点的总权重
            w2 = 0
            for n in w1:
                w2 += n
            area = block[i][1]
            averaged_weight = w2 / area if area > 0 else 0

            # 选择权重最大的区域
            if averaged_weight > maxWeight:
                maxIndex = i
                maxWeight = averaged_weight
    # 选择权重最大的区域作为车牌区域
    rect = block[maxIndex][0]
    return rect


if __name__ == "__main__":
    image = cv2.imread(img_path)
    # 调整尺寸
    image_resize = resize_img(image)
    # 转灰度图
    img_gray = cv2.cvtColor(image_resize, cv2.COLOR_BGR2GRAY)
    cv2.imshow("gray image", img_gray)
    cv2.waitKey(0)
    # 降噪
    image_blured = cv2.GaussianBlur(img_gray, (5,5), 0)
    cv2.imshow("GaussianBlur image", image_blured)
    cv2.waitKey(0)
    # 图像拉伸
    image_stretched = stretch(image_blured)
    cv2.imshow("Stretched image", image_stretched)
    cv2.waitKey(0)

    # 对图像进行开运算（先腐蚀后膨胀）
    r = 14
    h = w = r * 2 + 1
    kernel = np.zeros((h, w), np.uint8)
    cv2.circle(kernel, (r, r), r, 1, -1)
    img_opening = cv2.morphologyEx(image_stretched, cv2.MORPH_OPEN, kernel)
    # 差分
    img_absdiff = cv2.absdiff(img_gray, img_opening)
    cv2.imshow("Absfiff image",img_absdiff)
    cv2.waitKey(0)

    # 二值化
    ret, img_binary = binarization(img_absdiff)
    cv2.imshow("Binaried image",img_binary)
    cv2.waitKey(0)

    # 边缘检测
    img_canny = myCanny(img_binary, 100, 200)
    cv2.imshow("Cannied image", img_canny)
    cv2.waitKey(0)

    # 开闭运算划定车牌位置
    img_open_close = opening_with_closing(img_canny)

    # 车牌定位
    rect = locate_license(image_resize, img_open_close)
    print("车牌区域：", rect)
    img_copy = image_resize.copy()
    cv2.rectangle(img_copy, (rect[0],rect[1]), (rect[2], rect[3]), (0,0,255), 2)
    cv2.imshow('License image', img_copy)
    cv2.waitKey(0)
    cropped_img = image_resize[rect[1]:rect[3], rect[0]:rect[2]]
    cv2.imshow('License image cropped', cropped_img)
    cv2.waitKey(0)