import cv2
import numpy as np
import matplotlib.pyplot as plt

img_path = 'dataset5/5.bmp'

# 调整尺寸、转灰度图
def resize_img(img):
    height,width = img.shape[:-1]
    # 限制最大像素为400
    scale = 400/max(height, width)
    img = cv2.resize(img, None, fx=scale, fy=scale,interpolation=cv2.INTER_CUBIC)
    return img

# 灰度拉伸
def stretch(img):
    maxi = img.max()
    mini = img.min()
    for i in range(img.shape[0]):
        for j in range(img.shape[1]):
            img[i,j] = 255/(maxi-mini)*img[i,j] - (255*mini)/(maxi-mini)
    return img

# 二值化
def binarization(img):
    maxi = img.max()
    mini = img.min()
    x = maxi - ((maxi - mini)/2)
    ret, img_binary = cv2.threshold(img, 0, 255, cv2.THRESH_BINARY+cv2.THRESH_OTSU)
    # ret, img_binary = cv2.threshold(img, x, 255, cv2.THRESH_BIN ARY)
    return ret, img_binary

# 边缘检测
def myCanny(img, low_threshold, high_threshold):
    img_canny = cv2.Canny(img, low_threshold, high_threshold)
    return img_canny

# 车牌旋转
def rotate_license(angles, img, origin_image):
    areas = []
    for angle in angles:
        # 计算旋转矩阵
        center = (origin_image.shape[1] // 2, origin_image.shape[0] // 2)
        M = cv2.getRotationMatrix2D(center, angle, 1.0)
        # 进行仿射变换
        rotated_image = cv2.warpAffine(origin_image, M, (img.shape[1], img.shape[0]))
        # 轮廓检测
        contours, _ = cv2.findContours(img, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        # 计算最大轮廓的面积
        max_contour = max(contours, key=cv2.contourArea)
        area = cv2.contourArea(max_contour)
        areas.append(area)
        # 画图
        img_copy = rotated_image.copy()
        # img_copy = cv2.drawContours(img_copy, max_contour, -1, (255, 0, 0), 5)
        cv2.imshow(f'Angle = {angle}, Max Contour', img_copy)
        cv2.waitKey(0)
    print(areas)
    plt.figure(figsize=(8,6))
    plt.plot(angles,areas)
    plt.grid()
    plt.show()

if __name__ == "__main__":
    image = cv2.imread(img_path)
    # 调整尺寸
    image_resize = resize_img(image)
    # 转灰度图
    img_gray = cv2.cvtColor(image_resize, cv2.COLOR_BGR2GRAY)
    cv2.imshow("gray image", img_gray)
    cv2.waitKey(0)
    # 降噪
    image_blured = cv2.GaussianBlur(img_gray, (5,5), 0)
    cv2.imshow("GaussianBlur image", image_blured)
    cv2.waitKey(0)
    # 图像拉伸
    image_stretched = stretch(image_blured)
    cv2.imshow("Stretched image", image_stretched)
    cv2.waitKey(0)

    # 对图像进行开运算（先腐蚀后膨胀）
    r = 14
    h = w = r * 2 + 1
    kernel = np.zeros((h, w), np.uint8)
    cv2.circle(kernel, (r, r), r, 1, -1)
    img_opening = cv2.morphologyEx(image_stretched, cv2.MORPH_OPEN, kernel)
    # 差分
    img_absdiff = cv2.absdiff(img_gray, img_opening)
    cv2.imshow("Absfiff image",img_absdiff)
    cv2.waitKey(0)

    # 二值化
    ret, img_binary = binarization(img_absdiff)
    cv2.imshow("Binaried image",img_binary)
    cv2.waitKey(0)

    # 边缘检测
    img_canny = myCanny(img_binary, 100, 200)
    cv2.imshow("Cannied image", img_canny)
    cv2.waitKey(0)

    angles = [0, -2.5, -5, -7.5, -10, -12.5, -15]
    rotate_license(angles,img_canny,image)
