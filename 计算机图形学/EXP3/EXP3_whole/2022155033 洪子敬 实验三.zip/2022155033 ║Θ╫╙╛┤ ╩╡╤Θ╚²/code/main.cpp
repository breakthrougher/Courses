#include "Angel.h"
#include "TriMesh.h"
#include "Camera.h"
#include <vector>
#include <string>

int WIDTH = 600;
int HEIGHT = 600;
int mainWindow;
int currentDisplay = 1; // 1表示显示display_1，2表示显示display_2

struct openGLObject
{
	// 顶点数组对象
	GLuint vao;
	// 顶点缓存对象
	GLuint vbo;

	// 着色器程序
	GLuint program;
	// 着色器文件
	std::string vshader;
	std::string fshader;
	// 着色器变量
	GLuint pLocation;
	GLuint cLocation;
	GLuint nLocation;

	// 投影变换变量
	GLuint modelLocation;
	GLuint viewLocation;
	GLuint projectionLocation;

	// 阴影变量
	GLuint shadowLocation;
};


openGLObject mesh_object;
openGLObject plane_object;

Light* light = new Light();
TriMesh* mesh = new TriMesh();
Camera* camera = new Camera();
TriMesh* plane = new TriMesh();

void bindObjectAndData(TriMesh* mesh, openGLObject& object, const std::string& vshader, const std::string& fshader) {

	// 创建顶点数组对象
	glGenVertexArrays(1, &object.vao);  	// 分配1个顶点数组对象
	glBindVertexArray(object.vao);  	// 绑定顶点数组对象

	// 创建并初始化顶点缓存对象
	glGenBuffers(1, &object.vbo);
	glBindBuffer(GL_ARRAY_BUFFER, object.vbo);
	glBufferData(GL_ARRAY_BUFFER,
		mesh->getPoints().size() * sizeof(glm::vec3) + mesh->getColors().size() * sizeof(glm::vec3),
		NULL,
		GL_STATIC_DRAW);

	glBufferSubData(GL_ARRAY_BUFFER, 0, mesh->getPoints().size() * sizeof(glm::vec3), &mesh->getPoints()[0]);
	glBufferSubData(GL_ARRAY_BUFFER, mesh->getPoints().size() * sizeof(glm::vec3), mesh->getColors().size() * sizeof(glm::vec3), &mesh->getColors()[0]);

	object.vshader = vshader;
	object.fshader = fshader;
	object.program = InitShader(object.vshader.c_str(), object.fshader.c_str());

	// 从顶点着色器中初始化顶点的位置
	object.pLocation = glGetAttribLocation(object.program, "vPosition");
	glEnableVertexAttribArray(object.pLocation);
	glVertexAttribPointer(object.pLocation, 3, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(0));

	// 从顶点着色器中初始化顶点的颜色
	object.cLocation = glGetAttribLocation(object.program, "vColor");
	glEnableVertexAttribArray(object.cLocation);
	glVertexAttribPointer(object.cLocation, 3, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(mesh->getPoints().size() * sizeof(glm::vec3)));

	// @TODO: 从顶点着色器中初始化顶点的法向量
	object.nLocation = glGetAttribLocation(object.program, "vNormal");
	glEnableVertexAttribArray(object.nLocation);
	glVertexAttribPointer(object.nLocation, 3, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(mesh->getPoints().size() * sizeof(glm::vec3)));

	// 获得矩阵位置
	object.modelLocation = glGetUniformLocation(object.program, "model");
	object.viewLocation = glGetUniformLocation(object.program, "view");
	object.projectionLocation = glGetUniformLocation(object.program, "projection");

	object.shadowLocation = glGetUniformLocation(object.program, "isShadow");
}

void bindLightAndMaterial(TriMesh* mesh, openGLObject& object, Light* light, Camera* camera) {

	// 传递相机的位置
	glUniform3fv(glGetUniformLocation(object.program, "eye_position"), 1, &camera->eye[0]);

	// 传递物体的材质
	glm::vec4 meshAmbient = mesh->getAmbient();
	glm::vec4 meshDiffuse = mesh->getDiffuse();
	glm::vec4 meshSpecular = mesh->getSpecular();
	float meshShininess = mesh->getShininess();

	glUniform4fv(glGetUniformLocation(object.program, "material.ambient"), 1, &meshAmbient[0]);
	glUniform4fv(glGetUniformLocation(object.program, "material.diffuse"), 1, &meshDiffuse[0]);
	glUniform4fv(glGetUniformLocation(object.program, "material.specular"), 1, &meshSpecular[0]);
	glUniform1f(glGetUniformLocation(object.program, "material.shininess"), meshShininess);

	// 传递光源信息
	glm::vec4 lightAmbient = light->getAmbient();
	glm::vec4 lightDiffuse = light->getDiffuse();
	glm::vec4 lightSpecular = light->getSpecular();
	glm::vec3 lightPosition = light->getTranslation();
	glUniform4fv(glGetUniformLocation(object.program, "light.ambient"), 1, &lightAmbient[0]);
	glUniform4fv(glGetUniformLocation(object.program, "light.diffuse"), 1, &lightDiffuse[0]);
	glUniform4fv(glGetUniformLocation(object.program, "light.specular"), 1, &lightSpecular[0]);
	glUniform3fv(glGetUniformLocation(object.program, "light.position"), 1, &lightPosition[0]);

}

void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
	HEIGHT = height;
	WIDTH = width;
	glViewport(0, 0, width, height);
}


void init()
{
	std::string vshader, fshader;
	// 读取着色器并使用
	vshader = "shaders/vshader.glsl";
	fshader = "shaders/fshader.glsl";

	// 设置光源位置
	// 默认y轴方向3.0
	light->setTranslation(glm::vec3(3.0, 3.0, 0.0));
	light->setAmbient(glm::vec4(1.0, 1.0, 1.0, 1.0)); // 环境光
	light->setDiffuse(glm::vec4(1.0, 1.0, 1.0, 1.0)); // 漫反射
	light->setSpecular(glm::vec4(1.0, 1.0, 1.0, 1.0)); // 镜面反射

	// 设置物体的旋转位移
	mesh->setTranslation(glm::vec3(0.0, 0.5, 0.0));
	mesh->setRotation(glm::vec3(0, 0.0, 0.0));
	mesh->setScale(glm::vec3(1.0, 1.0, 1.0));

	// 设置材质
	mesh->setAmbient(glm::vec4(0.2, 0.2, 0.2, 1.0)); // 环境光
	mesh->setDiffuse(glm::vec4(0.7, 0.7, 0.7, 1.0)); // 漫反射
	mesh->setSpecular(glm::vec4(0.2, 0.2, 0.2, 1.0)); // 镜面反射
	mesh->setShininess(1.0); //高光系数

	bindObjectAndData(mesh, mesh_object, vshader, fshader);

	//设置阴影平面
	plane->generateSquare(glm::vec3(0.6, 0.8, 0.0));
	//plane->generateSquare(glm::vec3(0.7, 0.7, 0.7));
	plane->setRotation(glm::vec3(0, 90, 90));
	plane->setTranslation(glm::vec3(0, -0.001, 0));
	plane->setScale(glm::vec3(3, 3, 3));

	bindObjectAndData(plane, plane_object, vshader, fshader);

	// 灰色背景
	glClearColor(0.5, 0.5, 0.5, 1.0);
}


//绘制阴影
void drawShadow() {
	glBindVertexArray(mesh_object.vao);
	glUseProgram(mesh_object.program);
	//传递投影矩阵
	glm::vec3 light_pos = light->getTranslation();
	float lx = light_pos[0];
	float ly = light_pos[1];
	float lz = light_pos[2];
	glm::mat4 shadowProjMatrix(-ly, 0.0, 0.0, 0.0,
		lx, 0.0, lz, 1.0,
		0.0, 0.0, -ly, 0.0,
		0.0, 0.0, 0.0, -ly);
	glm::mat4 modelMatrix = mesh->getModelMatrix();
	glm::mat4 shadowModelMatrix = shadowProjMatrix * modelMatrix;

	glUniformMatrix4fv(mesh_object.modelLocation, 1, GL_FALSE, &shadowModelMatrix[0][0]);
	glUniformMatrix4fv(mesh_object.viewLocation, 1, GL_FALSE, &camera->viewMatrix[0][0]);
	glUniformMatrix4fv(mesh_object.projectionLocation, 1, GL_FALSE, &camera->projMatrix[0][0]);
	// 将着色器 isShadow 设置为0，表示正常绘制的颜色，如果是1着表示阴影
	glUniform1i(mesh_object.shadowLocation, 1);
	// 绘制
	glDrawArrays(GL_TRIANGLES, 0, mesh->getPoints().size());

	/* 绘制平面
	glBindVertexArray(plane_object.vao);
	glUseProgram(plane_object.program);
	modelMatrix = plane->getModelMatrix();
	glUniformMatrix4fv(plane_object.modelLocation, 1, GL_FALSE, &modelMatrix[0][0]);
	glUniformMatrix4fv(plane_object.viewLocation, 1, GL_FALSE, &camera->viewMatrix[0][0]);
	glUniformMatrix4fv(plane_object.projectionLocation, 1, GL_FALSE, &camera->projMatrix[0][0]);
	 将着色器 isShadow 设置为0，表示正常绘制的颜色，如果是1着表示阴影
	glUniform1i(plane_object.shadowLocation, 0);
	glDrawArrays(GL_TRIANGLES, 0, plane->getPoints().size());*/
}

//正交投影
void display_1()
{
	glViewport(0, 0, WIDTH, HEIGHT);

	camera->updateCamera();
	camera->viewMatrix = camera->lookAt(camera->eye, camera->at, camera->up);	// 调用 Camera::lookAt 函数计算视图变换矩阵
	camera->projMatrix = camera->ortho(-camera->scale, camera->scale, -camera->scale, camera->scale, camera->zNear, camera->zFar);

	glBindVertexArray(mesh_object.vao);

	glUseProgram(mesh_object.program);

	glm::mat4 modelMatrix = mesh->getModelMatrix(); // 物体模型的变换矩阵	

	// 传递投影变换矩阵
	glUniformMatrix4fv(mesh_object.modelLocation, 1, GL_FALSE, &modelMatrix[0][0]);
	glUniformMatrix4fv(mesh_object.viewLocation, 1, GL_FALSE, &camera->viewMatrix[0][0]);
	glUniformMatrix4fv(mesh_object.projectionLocation, 1, GL_FALSE, &camera->projMatrix[0][0]);
	// 将着色器 isShadow 设置为0，表示正常绘制的颜色，如果是1着表示阴影
	glUniform1i(mesh_object.shadowLocation, 0);

	// 将材质和光源数据传递给着色器
	bindLightAndMaterial(mesh, mesh_object, light, camera);
	// 绘制
	glDrawArrays(GL_TRIANGLES, 0, mesh->getPoints().size());
	//绘制阴影
	drawShadow();
}

//透视投影
void display_2()
{
	glViewport(0, 0, WIDTH, HEIGHT);

	camera->updateCamera();
	camera->viewMatrix = camera->lookAt(camera->eye, camera->at, camera->up);	// 调用 Camera::lookAt 函数计算视图变换矩阵
	camera->projMatrix = camera->perspective(camera->fov, camera->aspect, camera->zNear, camera->zFar);

	glBindVertexArray(mesh_object.vao);

	glUseProgram(mesh_object.program);

	glm::mat4 modelMatrix = mesh->getModelMatrix(); // 物体模型的变换矩阵	

	// 传递投影变换矩阵
	glUniformMatrix4fv(mesh_object.modelLocation, 1, GL_FALSE, &modelMatrix[0][0]);
	glUniformMatrix4fv(mesh_object.viewLocation, 1, GL_FALSE, &camera->viewMatrix[0][0]);
	glUniformMatrix4fv(mesh_object.projectionLocation, 1, GL_FALSE, &camera->projMatrix[0][0]);
	// 将着色器 isShadow 设置为0，表示正常绘制的颜色，如果是1着表示阴影
	glUniform1i(mesh_object.shadowLocation, 0);

	// 将材质和光源数据传递给着色器
	bindLightAndMaterial(mesh, mesh_object, light, camera);
	// 绘制
	glDrawArrays(GL_TRIANGLES, 0, mesh->getPoints().size());
	//绘制阴影
	drawShadow();
}

void display()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// 调用4个display分别在4个子视图内绘制立方体
	// 每个display使用的相机的的投影类型与计算方法都不一样
	if (currentDisplay == 1) {
		display_1(); // 显示正交投影
	}
	else if (currentDisplay == 2) {
		display_2(); // 显示透视投影
	}
}


void reshape(GLsizei w, GLsizei h)
{
	WIDTH = w;
	HEIGHT = h;
	glViewport(0, 0, WIDTH, HEIGHT);
}


void printHelp()
{
	std::cout << "Keyboard Usage" << std::endl;
	std::cout <<
		"ESC: 	Exit" << std::endl <<
		"H: 	Print help message" << std::endl <<
		"Camera parameters options:" << std::endl <<
		"SPACE: 	Reset Camera parameters" << std::endl <<
		"x/(shift+x): 	Increase/Decrease the rotate angle" << std::endl <<
		"y/(shift+y): 	Increase/Decrease the up angle" << std::endl <<
		"r/(shift+r): 	Increase/Decrease the distance between camera and object" << std::endl <<
		"f/(shift+f): 	Increase/Decrease FOV of perspective projection" << std::endl <<
		"n/(shift+n): 	change to ortho projection" << std::endl << 
		"m/(shift+m): 	change to perspective projection" << std::endl <<
		"Object Options:" << std::endl <<
		"Q:	   change to sphere object" << std::endl <<
		"A:    change to Pikachu object" << std::endl <<
		"W:	   change to Squirtle object" << std::endl <<
		"S:    change to sphere_coarse object" << std::endl <<
		"Materials Options:" << std::endl <<
		"-:		Reset material parameters" << std::endl <<
		"(shift) + 1/2/3:	Change ambient parameters" << std::endl <<
		"(shift) + 4/5/6:	Change diffuse parameters" << std::endl <<
		"(shift) + 7/8/9:	Change specular parameters" << std::endl <<
		"(shift) + 0:		Change shininess parameters" << std::endl;

}


void mainWindow_key_callback(GLFWwindow* window, int key, int scancode, int action, int mode)
{
	float tmp;
	glm::vec4 ambient, diffuse, specular;
	float shininess;
	// 'ESC键退出'
	if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
	{
		glfwSetWindowShouldClose(window, GL_TRUE);
	}
	else if (key == GLFW_KEY_H && action == GLFW_PRESS)
	{
		printHelp();
	}
	else if (key == GLFW_KEY_Q && action == GLFW_PRESS)
	{
		std::cout << "read sphere.off" << std::endl;
		mesh = new TriMesh();
		mesh->readOff("./assets/sphere.off");
		init();
	}
	else if (key == GLFW_KEY_A && action == GLFW_PRESS)
	{
		std::cout << "read Pikachu.off" << std::endl;
		mesh = new TriMesh();
		mesh->readOff("./assets/Pikachu.off");
		init();
	}
	else if (key == GLFW_KEY_W && action == GLFW_PRESS)
	{
		std::cout << "read Squirtle.off" << std::endl;
		mesh = new TriMesh();
		mesh->readOff("./assets/Squirtle.off");
		init();
	}
	else if (key == GLFW_KEY_S && action == GLFW_PRESS)
	{
		std::cout << "read sphere_coarse.off" << std::endl;
		mesh = new TriMesh();
		mesh->readOff("./assets/sphere_coarse.off");
		init();
	}
	else if (key == GLFW_KEY_1 && action == GLFW_PRESS && mode == 0x0000)
	{
		ambient = mesh->getAmbient();
		tmp = ambient.x;
		ambient.x = std::min(tmp + 0.1, 1.0);
		mesh->setAmbient(ambient);
	}
	else if (key == GLFW_KEY_1 && action == GLFW_PRESS && mode == GLFW_MOD_SHIFT)
	{
		ambient = mesh->getAmbient();
		tmp = ambient.x;
		ambient.x = std::max(tmp - 0.1, 0.0);
		mesh->setAmbient(ambient);
	}
	else if (key == GLFW_KEY_2 && action == GLFW_PRESS && mode == 0x0000)
	{
		ambient = mesh->getAmbient();
		tmp = ambient.y;
		ambient.y = std::min(tmp + 0.1, 1.0);
		mesh->setAmbient(ambient);
	}
	else if (key == GLFW_KEY_2 && action == GLFW_PRESS && mode == GLFW_MOD_SHIFT)
	{
		ambient = mesh->getAmbient();
		tmp = ambient.y;
		ambient.y = std::max(tmp - 0.1, 0.0);
		mesh->setAmbient(ambient);
	}
	else if (key == GLFW_KEY_3 && action == GLFW_PRESS && mode == 0x0000)
	{
		ambient = mesh->getAmbient();
		tmp = ambient.z;
		ambient.z = std::min(tmp + 0.1, 1.0);
		mesh->setAmbient(ambient);
	}
	else if (key == GLFW_KEY_3 && action == GLFW_PRESS && mode == GLFW_MOD_SHIFT)
	{
		ambient = mesh->getAmbient();
		tmp = ambient.z;
		ambient.z = std::max(tmp - 0.1, 0.0);
		mesh->setAmbient(ambient);
	}
	else if (key == GLFW_KEY_MINUS && action == GLFW_PRESS && mode == 0x0000)
	{
		mesh->setAmbient(glm::vec4(0.2, 0.2, 0.2, 1.0));
		mesh->setDiffuse(glm::vec4(0.7, 0.7, 0.7, 1.0));
		mesh->setSpecular(glm::vec4(0.2, 0.2, 0.2, 1.0));
		mesh->setShininess(1.0);
	}
	// @TODO: Task4 添加更多交互 1~9增减反射系数（1~3已写好），0增减高光指数
	else if (key == GLFW_KEY_4 && action == GLFW_PRESS && mode == 0x0000)
	{
		diffuse = mesh->getDiffuse();
		tmp = diffuse.x;
		diffuse.x = std::min(tmp + 0.1, 1.0);
		mesh->setDiffuse(diffuse);
	}
	else if (key == GLFW_KEY_4 && action == GLFW_PRESS && mode == GLFW_MOD_SHIFT)
	{
		diffuse = mesh->getDiffuse();
		tmp = diffuse.x;
		diffuse.x = std::max(tmp - 0.1, 0.0);
		mesh->setDiffuse(diffuse);
	}
	else if (key == GLFW_KEY_5 && action == GLFW_PRESS && mode == 0x0000)
	{
		diffuse = mesh->getDiffuse();
		tmp = diffuse.y;
		diffuse.y = std::min(tmp + 0.1, 1.0);
		mesh->setDiffuse(diffuse);
	}
	else if (key == GLFW_KEY_5 && action == GLFW_PRESS && mode == GLFW_MOD_SHIFT)
	{
		diffuse = mesh->getDiffuse();
		tmp = diffuse.y;
		diffuse.y = std::max(tmp - 0.1, 0.0);
		mesh->setDiffuse(diffuse);
	}
	else if (key == GLFW_KEY_6 && action == GLFW_PRESS && mode == 0x0000)
	{
		diffuse = mesh->getDiffuse();
		tmp = diffuse.z;
		diffuse.z = std::min(tmp + 0.1, 1.0);
		mesh->setDiffuse(diffuse);
	}
	else if (key == GLFW_KEY_6 && action == GLFW_PRESS && mode == GLFW_MOD_SHIFT)
	{
		diffuse = mesh->getDiffuse();
		tmp = diffuse.z;
		diffuse.z = std::max(tmp - 0.1, 0.0);
		mesh->setDiffuse(diffuse);
	}
	else if (key == GLFW_KEY_7 && action == GLFW_PRESS && mode == 0x0000)
	{
		specular = mesh->getSpecular();
		tmp = specular.x;
		specular.x = std::min(tmp + 0.1, 1.0);
		mesh->setSpecular(specular);
	}
	else if (key == GLFW_KEY_7 && action == GLFW_PRESS && mode == GLFW_MOD_SHIFT)
	{
		specular = mesh->getSpecular();
		tmp = specular.x;
		specular.x = std::max(tmp - 0.1, 0.0);
		mesh->setSpecular(specular);
	}
	else if (key == GLFW_KEY_8 && action == GLFW_PRESS && mode == 0x0000)
	{
		specular = mesh->getSpecular();
		tmp = specular.y;
		specular.y = std::min(tmp + 0.1, 1.0);
		mesh->setSpecular(specular);
	}
	else if (key == GLFW_KEY_8 && action == GLFW_PRESS && mode == GLFW_MOD_SHIFT)
	{
		specular = mesh->getSpecular();
		tmp = specular.y;
		specular.y = std::max(tmp - 0.1, 0.0);
		mesh->setSpecular(specular);
	}
	else if (key == GLFW_KEY_9 && action == GLFW_PRESS && mode == 0x0000)
	{
		specular = mesh->getSpecular();
		tmp = specular.z;
		specular.z = std::min(tmp + 0.1, 1.0);
		mesh->setSpecular(specular);
	}
	else if (key == GLFW_KEY_9 && action == GLFW_PRESS && mode == GLFW_MOD_SHIFT)
	{
		specular = mesh->getSpecular();
		tmp = specular.z;
		specular.z = std::max(tmp - 0.1, 0.0);
		mesh->setSpecular(specular);
	}
	else if (key == GLFW_KEY_0 && action == GLFW_PRESS && mode == 0x0000)
	{
		shininess = mesh->getShininess();
		shininess = std::min(shininess + 1.0, 128.0);
		mesh->setShininess(shininess);
	}
	else if (key == GLFW_KEY_0 && action == GLFW_PRESS && mode == GLFW_MOD_SHIFT)
	{
		shininess = mesh->getShininess();
		specular.z = std::max(shininess - 1.0, 1.0);
		mesh->setShininess(shininess);
	}
	else if (key == GLFW_KEY_N && action == GLFW_PRESS) {
		currentDisplay = 1; // 切换到 display_1
	}
	else if (key == GLFW_KEY_M && action == GLFW_PRESS) {
		currentDisplay = 2; // 切换到 display_2
	}
	else
	{
		camera->keyboard(key, action, mode);
	}
}

void mouse_button_callback(GLFWwindow* window, int button, int action, int mods)
{
	if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_PRESS)
	{
		double x, z;
		glfwGetCursorPos(window, &x, &z);

		float half_winx = WIDTH / 2.0;
		float half_winz = HEIGHT / 2.0;
		float lx = float(x - half_winx) / half_winx;
		float lz = float(HEIGHT - z - half_winz) / half_winz;

		glm::vec3 pos = light->getTranslation();

		pos.x = lx;
		pos.z = lz;

		//重新展示阴影
		init();
		light->setTranslation(pos);
		display();
	}
}

void cleanData() {
	mesh->cleanData();

	delete camera;

	camera = NULL;

	// 释放内存
	delete mesh;
	mesh = NULL;
	delete plane;
	plane = NULL;

	// 删除绑定的对象
	glDeleteVertexArrays(1, &mesh_object.vao);
	glDeleteBuffers(1, &mesh_object.vbo);
	glDeleteProgram(mesh_object.program);

	glDeleteVertexArrays(1, &plane_object.vao);
	glDeleteBuffers(1, &plane_object.vbo);
	glDeleteProgram(plane_object.program);
}


int main(int argc, char** argv)
{
	glfwInit();

	// 开启超采样，如果绘制图形仍然锯齿感很严重的话，可以尝试调大后面的参数值。
	glfwWindowHint(GLFW_SAMPLES, 5);

	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif


	GLFWwindow* mainwindow = glfwCreateWindow(WIDTH, HEIGHT, "2022155033_HZJ_EXP3", NULL, NULL);
	if (mainwindow == NULL)
	{
		std::cout << "Failed to create GLFW window!" << std::endl;
		glfwTerminate();
		return -1;
	}
	glfwMakeContextCurrent(mainwindow);
	glfwSetFramebufferSizeCallback(mainwindow, framebuffer_size_callback);
	glfwSetKeyCallback(mainwindow, mainWindow_key_callback);
	glfwSetMouseButtonCallback(mainwindow, mouse_button_callback);
	if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
	{
		std::cout << "Failed to initialize GLAD" << std::endl;
		return -1;
	}
	glEnable(GL_DEPTH_TEST);
	mesh->readOff("./assets/sphere.off");
	init();
	printHelp();
	while (!glfwWindowShouldClose(mainwindow))
	{

		display();
		glfwSwapBuffers(mainwindow);
		glfwPollEvents();

	}
	glfwTerminate();
	return 0;
}

