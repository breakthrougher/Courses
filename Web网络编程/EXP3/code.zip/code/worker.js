// 优化后的质数判断函数
function isPrime(num) {
    if (num <= 1) return false;
    if (num <= 3) return true;
    if (num % 2 === 0 || num % 3 === 0) return false;

    for (let i = 5; i * i <= num; i += 6) {
        if (num % i === 0 || num % (i + 2) === 0) {
            return false;
        }
    }
    return true;
}

self.onmessage = function(event) {
    let count = 0;
    const {start, end} = event.data;

    for (let num = start; num <= end; num++) {
        //每1000个数发送一次进度
        if (num % 1000 === 0) {
            self.postMessage({type: 'progress', current: count, total: num});
        }
        if (isPrime(num)) {
            count++;
        }
    }

    self.postMessage({type: 'result', count: count});
}