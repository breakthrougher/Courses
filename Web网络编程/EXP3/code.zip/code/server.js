const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = 3000; // 端口号，可自定义

// 创建服务器
const server = http.createServer((req, res) => {
  // 处理不同的请求路径
  let filePath = req.url === '/' ? '12WebWorker.html' : req.url;
  const extname = String(path.extname(filePath)).toLowerCase();
  
  // 定义文件类型映射
  const mimeTypes = {
    '.html': 'text/html',
    '.js': 'text/javascript',
    '.css': 'text/css'
  };
  
  // 获取文件绝对路径
  filePath = path.join(__dirname, filePath);
  
  // 读取文件并返回响应
  fs.readFile(filePath, (err, content) => {
    if (err) {
      if (err.code === 'ENOENT') {
        // 文件不存在
        res.statusCode = 404;
        res.end(`404 Not Found - ${filePath}`);
      } else {
        // 服务器错误
        res.statusCode = 500;
        res.end(`Server Error: ${err.code}`);
      }
    } else {
      // 成功返回文件
      const contentType = mimeTypes[extname] || 'application/octet-stream';
      res.statusCode = 200;
      res.setHeader('Content-Type', contentType);
      res.end(content, 'utf-8');
    }
  });
});

// 启动服务器
server.listen(PORT, () => {
  console.log(`服务器运行在 http://localhost:${PORT}`);
  console.log(`WebWorker 测试页面: http://localhost:${PORT}/12WebWorker.html`);
});