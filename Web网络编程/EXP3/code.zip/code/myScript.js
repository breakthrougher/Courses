// 导航栏滚动效果
const navbar = document.getElementById('navbar');
window.addEventListener('scroll', () => {
    if (window.scrollY > 50) {
    navbar.classList.add('shadow-md');
    navbar.classList.remove('shadow-sm');
    } else {
    navbar.classList.remove('shadow-md');
    navbar.classList.add('shadow-sm');
    }
});

// 模态框控制
const authModal = document.getElementById('authModal');
const loginTab = document.getElementById('loginTab');
const registerTab = document.getElementById('registerTab');
const loginForm = document.getElementById('loginForm');
const registerForm = document.getElementById('registerForm');
const closeModal = document.getElementById('closeModal');
const loginBtn = document.getElementById('loginBtn');
const registerBtn = document.getElementById('registerBtn');
const heroLoginBtn = document.getElementById('heroLoginBtn');
const heroRegisterBtn = document.getElementById('heroRegisterBtn');
const switchToRegister = document.getElementById('switchToRegister');
const switchToLogin = document.getElementById('switchToLogin');

function openModal(tab = 'login') {
    authModal.classList.remove('opacity-0', 'pointer-events-none');
    authModal.querySelector('.transform').classList.remove('scale-95');
    authModal.querySelector('.transform').classList.add('scale-100');
    
    if (tab === 'login') {
    showLogin();
    } else {
    showRegister();
    }
}

function closeModalFunc() {
    authModal.classList.add('opacity-0', 'pointer-events-none');
    authModal.querySelector('.transform').classList.remove('scale-100');
    authModal.querySelector('.transform').classList.add('scale-95');
}

function showLogin() {
    loginTab.classList.add('text-primary', 'border-primary');
    loginTab.classList.remove('text-muted', 'border-transparent');
    registerTab.classList.add('text-muted', 'border-transparent');
    registerTab.classList.remove('text-primary', 'border-primary');
    loginForm.classList.remove('hidden');
    registerForm.classList.add('hidden');
}

function showRegister() {
    registerTab.classList.add('text-primary', 'border-primary');
    registerTab.classList.remove('text-muted', 'border-transparent');
    loginTab.classList.add('text-muted', 'border-transparent');
    loginTab.classList.remove('text-primary', 'border-primary');
    registerForm.classList.remove('hidden');
    loginForm.classList.add('hidden');
}

loginBtn.addEventListener('click', () => openModal('login'));
registerBtn.addEventListener('click', () => openModal('register'));
heroLoginBtn.addEventListener('click', () => openModal('login'));
heroRegisterBtn.addEventListener('click', () => openModal('register'));
switchToRegister.addEventListener('click', () => openModal('register'));
switchToLogin.addEventListener('click', () => openModal('login'));
closeModal.addEventListener('click', closeModalFunc);
authModal.addEventListener('click', (e) => {
    if (e.target === authModal) {
    closeModalFunc();
    }
});
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && !authModal.classList.contains('pointer-events-none')) {
    closeModalFunc();
    }
});

// 密码可见性切换
const toggleLoginPassword = document.getElementById('toggleLoginPassword');
const loginPassword = document.getElementById('loginPassword');
const toggleRegisterPassword = document.getElementById('toggleRegisterPassword');
const registerPassword = document.getElementById('registerPassword');
const toggleConfirmPassword = document.getElementById('toggleConfirmPassword');
const registerConfirmPassword = document.getElementById('registerConfirmPassword');

toggleLoginPassword.addEventListener('click', () => {
    const type = loginPassword.getAttribute('type') === 'password' ? 'text' : 'password';
    loginPassword.setAttribute('type', type);
    toggleLoginPassword.querySelector('i').classList.toggle('fa-eye');
    toggleLoginPassword.querySelector('i').classList.toggle('fa-eye-slash');
});

toggleRegisterPassword.addEventListener('click', () => {
    const type = registerPassword.getAttribute('type') === 'password' ? 'text' : 'password';
    registerPassword.setAttribute('type', type);
    toggleRegisterPassword.querySelector('i').classList.toggle('fa-eye');
    toggleRegisterPassword.querySelector('i').classList.toggle('fa-eye-slash');
});

toggleConfirmPassword.addEventListener('click', () => {
    const type = registerConfirmPassword.getAttribute('type') === 'password' ? 'text' : 'password';
    registerConfirmPassword.setAttribute('type', type);
    toggleConfirmPassword.querySelector('i').classList.toggle('fa-eye');
    toggleConfirmPassword.querySelector('i').classList.toggle('fa-eye-slash');
});

// 注册表单验证
const registerName = document.getElementById('registerName');
const registerEmail = document.getElementById('registerEmail');
const usernameFeedback = document.getElementById('usernameFeedback');
const emailFeedback = document.getElementById('emailFeedback');
const passwordStrength = document.getElementById('passwordStrength');
const confirmFeedback = document.getElementById('confirmFeedback');
const reqLength = document.getElementById('reqLength');
const reqUpper = document.getElementById('reqUpper');
const reqLower = document.getElementById('reqLower');
const reqNumber = document.getElementById('reqNumber');
const successToast = document.getElementById('successToast');

registerName.addEventListener('input', () => {
    if (registerName.value.length < 4) {
    usernameFeedback.classList.remove('hidden');
    registerName.classList.add('border-red-500');
    registerName.classList.remove('border-gray-300');
    } else {
    usernameFeedback.classList.add('hidden');
    registerName.classList.remove('border-red-500');
    registerName.classList.add('border-gray-300');
    }
});

registerEmail.addEventListener('input', () => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(registerEmail.value)) {
    emailFeedback.classList.remove('hidden');
    registerEmail.classList.add('border-red-500');
    registerEmail.classList.remove('border-gray-300');
    } else {
    emailFeedback.classList.add('hidden');
    registerEmail.classList.remove('border-red-500');
    registerEmail.classList.add('border-gray-300');
    }
});

registerPassword.addEventListener('input', () => {
    const password = registerPassword.value;
    let strength = 0;
    
    // 长度验证
    if (password.length >= 8) {
    reqLength.classList.remove('fa-times-circle', 'text-red-500');
    reqLength.classList.add('fa-check-circle', 'text-green-500');
    strength++;
    } else {
    reqLength.classList.remove('fa-check-circle', 'text-green-500');
    reqLength.classList.add('fa-times-circle', 'text-red-500');
    }
    
    // 大写字母验证
    if (/[A-Z]/.test(password)) {
    reqUpper.classList.remove('fa-times-circle', 'text-red-500');
    reqUpper.classList.add('fa-check-circle', 'text-green-500');
    strength++;
    } else {
    reqUpper.classList.remove('fa-check-circle', 'text-green-500');
    reqUpper.classList.add('fa-times-circle', 'text-red-500');
    }
    
    // 小写字母验证
    if (/[a-z]/.test(password)) {
    reqLower.classList.remove('fa-times-circle', 'text-red-500');
    reqLower.classList.add('fa-check-circle', 'text-green-500');
    strength++;
    } else {
    reqLower.classList.remove('fa-check-circle', 'text-green-500');
    reqLower.classList.add('fa-times-circle', 'text-red-500');
    }
    
    // 数字验证
    if (/[0-9]/.test(password)) {
    reqNumber.classList.remove('fa-times-circle', 'text-red-500');
    reqNumber.classList.add('fa-check-circle', 'text-green-500');
    strength++;
    } else {
    reqNumber.classList.remove('fa-check-circle', 'text-green-500');
    reqNumber.classList.add('fa-times-circle', 'text-red-500');
    }
    
    // 显示密码强度
    if (strength === 0) {
    passwordStrength.textContent = '';
    passwordStrength.className = 'text-xs px-2 py-1 rounded-full';
    } else if (strength === 1) {
    passwordStrength.textContent = '弱';
    passwordStrength.className = 'text-xs px-2 py-1 rounded-full bg-red-100 text-red-800';
    } else if (strength === 2) {
    passwordStrength.textContent = '中';
    passwordStrength.className = 'text-xs px-2 py-1 rounded-full bg-yellow-100 text-yellow-800';
    } else if (strength === 3) {
    passwordStrength.textContent = '强';
    passwordStrength.className = 'text-xs px-2 py-1 rounded-full bg-green-100 text-green-800';
    } else {
    passwordStrength.textContent = '非常强';
    passwordStrength.className = 'text-xs px-2 py-1 rounded-full bg-indigo-100 text-indigo-800';
    }
    
    // 确认密码验证
    validateConfirmPassword();
});

registerConfirmPassword.addEventListener('input', validateConfirmPassword);

function validateConfirmPassword() {
    if (registerConfirmPassword.value !== registerPassword.value) {
    confirmFeedback.classList.remove('hidden');
    registerConfirmPassword.classList.add('border-red-500');
    registerConfirmPassword.classList.remove('border-gray-300');
    } else {
    confirmFeedback.classList.add('hidden');
    registerConfirmPassword.classList.remove('border-red-500');
    registerConfirmPassword.classList.add('border-gray-300');
    }
}

// 表单提交
document.getElementById('loginFormFields').addEventListener('submit', (e) => {
    e.preventDefault();
    // 这里可以添加登录逻辑
    closeModalFunc();
    // 显示登录成功提示
    showToast('登录成功！欢迎回来');
});

document.getElementById('registerFormFields').addEventListener('submit', (e) => {
    e.preventDefault();
    // 这里可以添加注册逻辑
    closeModalFunc();
    // 显示注册成功提示
    showToast('注册成功！欢迎加入SoundWave');
});

function showToast(message) {
    successToast.querySelector('span').textContent = message;
    successToast.classList.remove('opacity-0', 'pointer-events-none');
    setTimeout(() => {
    successToast.classList.add('opacity-0', 'pointer-events-none');
    }, 3000);
}

// 统计数字动画
function animateCounter(elementId, target, duration = 2000) {
    const element = document.getElementById(elementId);
    if (!element) return;
    
    let start = 0;
    const increment = target / (duration / 16);
    
    const timer = setInterval(() => {
    start += increment;
    if (start >= target) {
        element.textContent = target.toLocaleString();
        clearInterval(timer);
    } else {
        element.textContent = Math.floor(start).toLocaleString();
    }
    }, 16);
}

// 图表初始化
function initCharts() {
    // 音乐类型分布图表
    const genreCtx = document.getElementById('genreChart').getContext('2d');
    new Chart(genreCtx, {
    type: 'doughnut',
    data: {
        labels: ['流行', '摇滚', '电子', '嘻哈', '爵士', '古典', '其他'],
        datasets: [{
        data: [30, 20, 15, 12, 8, 7, 8],
        backgroundColor: [
            '#6366F1', // 主色
            '#8B5CF6', // 紫色
            '#EC4899', // 粉色
            '#10B981', // 绿色
            '#F59E0B', // 橙色
            '#3B82F6', // 蓝色
            '#6B7280'  // 灰色
        ],
        borderWidth: 0
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
        legend: {
            position: 'right',
        }
        }
    }
    });

    // 每日活跃用户图表
    const activityCtx = document.getElementById('activityChart').getContext('2d');
    new Chart(activityCtx, {
    type: 'line',
    data: {
        labels: ['周一', '周二', '周三', '周四', '周五', '周六', '周日'],
        datasets: [{
        label: '活跃用户数',
        data: [50000, 65000, 55000, 70000, 85000, 90000, 80000],
        backgroundColor: 'rgba(99, 102, 241, 0.1)',
        borderColor: '#6366F1',
        borderWidth: 2,
        tension: 0.3,
        fill: true
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
        legend: {
            display: false
        }
        },
        scales: {
        y: {
            beginAtZero: true,
            ticks: {
            callback: function(value) {
                return value.toLocaleString();
            }
            }
        }
        }
    }
    });
}

// 页面加载完成后初始化
window.addEventListener('load', () => {
    // 初始化图表
    initCharts();
    
    // 初始化统计数字动画（滚动到视图时触发）
    const statsSection = document.querySelector('#statsUsers').closest('section');
    const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
        animateCounter('statsUsers', 1500000);
        animateCounter('statsSongs', 50000000);
        animateCounter('statsPlaylists', 8500000);
        animateCounter('statsCountries', 180);
        observer.unobserve(entry.target);
        }
    });
    }, { threshold: 0.1 });
    
    observer.observe(statsSection);
});